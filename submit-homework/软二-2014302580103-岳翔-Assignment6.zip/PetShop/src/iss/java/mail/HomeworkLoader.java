package iss.java.mail;


import org.reflections.Reflections;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Random;
import java.util.Set;


public class HomeworkLoader {
	private String identifyingCode;
	
    public HomeworkLoader(String emailAdress,String name)throws MessagingException, IOException, InterruptedException, IllegalAccessException, InstantiationException {
        Reflections reflections = new Reflections("iss.java.mail");
        Set<Class<? extends IMailService>> impls = reflections.getSubTypesOf(IMailService.class);
        Class<? extends IMailService> homework = impls.iterator().next();
        IMailService service = homework.newInstance();
        service.connect();
        int random1 = new Random().nextInt(4)+1;
        int random2 = new Random().nextInt(4)+1;
        int random3 = new Random().nextInt(4)+1;
        int random4 = new Random().nextInt(4)+1;
        identifyingCode=Integer.toString(random1*1000+random2*100+random3*10+random4);
        service.send(emailAdress, "��ӭ��ע��������ﳬ�У���","�𾴵�"+name+"����/Ůʿ����ӭ��ע��������ﳬ�У�"
        		+ "���ڳ����̵�ע����֤��:"+identifyingCode);
        System.out.println("mail sent");
    }
    
    public String getIdentifyingCode()
    {
    	return identifyingCode;
    }
    
    
}

