package iss.java.mail;
import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.internet.MimeUtility;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPMessage;

/**
 * ����һϵ���ʼ��շ�������
 */

public class MyEmailService2014302580103 implements IMailService {

	private transient Properties props;
	private transient MyAuthenticator authenticator;
	private transient Session session;
	private InternetAddress internetAddress;
	private final String smtpHostName = "smtp.sina.com";
	private final String userName = "whu_alert@sina.com";
	private final String password = "yxX960704";
	private MimeMessage message;
	/**
	 * ��ʼ�����������е��ʼ�������
	 * 
	 * @throws MessagingException
	 *             ��ʼ���������쳣
	 */
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		authenticator = new MyAuthenticator(userName, password);//

	}

	/**
	 * ���͵����ʼ�.����
	 * 
	 * @param recipient
	 *            �ռ��������ַ
	 * @param subject
	 *            �ʼ�����
	 * @param content
	 *            �ʼ�����
	 * @throws MessagingException
	 *             �����ʼ�����
	 *
	 */
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		
		props =System.getProperties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", smtpHostName);
		session = Session.getInstance(props, authenticator);
		
		message = new MimeMessage(session);
		internetAddress = new InternetAddress(authenticator.getUsername());
		message.setFrom(internetAddress);
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		message.setSubject(subject);
		message.setContent(content.toString(), "text/html;charset=utf-8");
		Transport.send(message);
	}
}