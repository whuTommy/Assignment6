package User;

public class User {
	private static String username;
	private static double balance;
	private static String emailAddress;
	private static String truename;
	
	public static double getBalance() {
		return balance;
	}
	public static void setBalance(double balance) {
		User.balance = balance;
	}
	public static String getUsername() {
		return username;
	}
	public static void setUsername(String username) {
		User.username = username;
	}
	public static String getEmailAddress() {
		return emailAddress;
	}
	public static void setEmailAddress(String emailAddress) {
		User.emailAddress = emailAddress;
	}
	public static String getTruename() {
		return truename;
	}
	public static void setTruename(String truename) {
		User.truename = truename;
	}
	
}
