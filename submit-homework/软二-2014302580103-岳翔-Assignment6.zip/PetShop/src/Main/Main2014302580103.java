package Main;

import GUI.HomePage_1;
import GUI.LoginPage;

public class Main2014302580103 {
	
	
	public static void main(String[] args) {
		LoginPage loginPage=new LoginPage();	
	}
	
}
