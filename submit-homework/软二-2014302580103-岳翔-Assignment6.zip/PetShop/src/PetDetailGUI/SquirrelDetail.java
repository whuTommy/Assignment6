package PetDetailGUI;

import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import GUI.HomePage_1;
import GUI.ShoppingCart;
import Pet.Pet;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SquirrelDetail extends JFrame {

	private JPanel contentPane;
	private JTextField IDField;
	private JTextField nameField;
	private JTextField eatFiled;
	private JTextField drinkField;
	private JTextField liveField;
	private JTextField hobbyField;
	private JTextField priceField;
	private JTextField stockField;

	private final String DBDRIVER = "com.mysql.jdbc.Driver";
	private final String DBURL = "jdbc:mysql://127.0.0.1:3306/my_schema";// ��ַ
	private JTextField numField;
	
	private int num;//��������
	
	private int clickNum=0;//�������
	
	public SquirrelDetail() throws Exception {
		
		
		
		int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((curWidth - 500) / 2, (curHeight - 363) / 2, 500, 363);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		this.setVisible(true);

		JLabel lblNewLabel = new JLabel(new ImageIcon("image/squirrel.png"));
		lblNewLabel.setBounds(62, 49, 130, 100);
		contentPane.add(lblNewLabel);

		IDField = new JTextField();
		IDField.setText("6");
		IDField.setEditable(false);
		IDField.setColumns(10);
		IDField.setBounds(296, 49, 164, 21);
		contentPane.add(IDField);

		JLabel label = new JLabel("ID:");
		label.setFont(new Font("����", Font.PLAIN, 13));
		label.setBounds(251, 52, 54, 15);
		contentPane.add(label);

		nameField = new JTextField();
		nameField.setEditable(false);
		nameField.setColumns(10);
		nameField.setBounds(296, 87, 164, 21);
		contentPane.add(nameField);

		JLabel label_1 = new JLabel("Name:");
		label_1.setFont(new Font("����", Font.PLAIN, 13));
		label_1.setBounds(251, 90, 54, 15);
		contentPane.add(label_1);

		JLabel lblEat = new JLabel("Eat:");
		lblEat.setFont(new Font("����", Font.PLAIN, 13));
		lblEat.setBounds(251, 130, 54, 15);
		contentPane.add(lblEat);

		eatFiled = new JTextField();
		eatFiled.setEditable(false);
		eatFiled.setColumns(10);
		eatFiled.setBounds(296, 127, 164, 21);
		contentPane.add(eatFiled);

		JLabel lblDrink = new JLabel("Drink:");
		lblDrink.setFont(new Font("����", Font.PLAIN, 13));
		lblDrink.setBounds(251, 171, 54, 15);
		contentPane.add(lblDrink);

		drinkField = new JTextField();
		drinkField.setEditable(false);
		drinkField.setColumns(10);
		drinkField.setBounds(296, 168, 164, 21);
		contentPane.add(drinkField);

		JLabel lblLive = new JLabel("Live:");
		lblLive.setFont(new Font("����", Font.PLAIN, 13));
		lblLive.setBounds(251, 213, 54, 15);
		contentPane.add(lblLive);

		liveField = new JTextField();
		liveField.setEditable(false);
		liveField.setColumns(10);
		liveField.setBounds(296, 210, 164, 21);
		contentPane.add(liveField);

		JLabel lblHoppy = new JLabel("Hobby:");
		lblHoppy.setFont(new Font("����", Font.PLAIN, 13));
		lblHoppy.setBounds(251, 255, 54, 15);
		contentPane.add(lblHoppy);

		hobbyField = new JTextField();
		hobbyField.setEditable(false);
		hobbyField.setColumns(10);
		hobbyField.setBounds(296, 252, 164, 21);
		contentPane.add(hobbyField);

		JLabel lblPrice = new JLabel("Price:");
		lblPrice.setFont(new Font("����", Font.PLAIN, 13));
		lblPrice.setBounds(57, 184, 54, 15);
		contentPane.add(lblPrice);

		priceField = new JTextField();
		priceField.setEditable(false);
		priceField.setColumns(10);
		priceField.setBounds(102, 181, 90, 21);
		contentPane.add(priceField);

		JLabel lblSt = new JLabel("Stock:");
		lblSt.setFont(new Font("����", Font.PLAIN, 13));
		lblSt.setBounds(57, 223, 54, 15);
		contentPane.add(lblSt);

		stockField = new JTextField();
		stockField.setEditable(false);
		stockField.setColumns(10);
		stockField.setBounds(102, 220, 90, 21);
		contentPane.add(stockField);
		
		JButton btn_shoppingCart = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");// ���빺�ﳵ
		btn_shoppingCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clickNum++;
				if (clickNum == 1) {
					int num = Integer.parseInt(numField.getText());
					int stockNum = Integer.parseInt(stockField.getText());
					if (num <= stockNum) {
						Pet.setId(Integer.parseInt(IDField.getText()));
						Pet.setNum(Integer.parseInt(numField.getText()));
						Pet.setStockNum(Integer.parseInt(stockField.getText()));

						JOptionPane.showMessageDialog(null, "��ϲ�����ɹ����빺�ﳵ��",
								"�ɹ�", JOptionPane.PLAIN_MESSAGE);
					} else {
						clickNum=0;
						JOptionPane.showMessageDialog(null, "��������������棬���޸Ĺ���������",
								"����", JOptionPane.PLAIN_MESSAGE);
					}
				} else {
					
					JOptionPane.showMessageDialog(null, "�����ظ����ӣ�", "����",
							JOptionPane.PLAIN_MESSAGE);
				}

			}
		});
		btn_shoppingCart.setBounds(70, 283, 107, 23);
		contentPane.add(btn_shoppingCart);

		JButton btn_back = new JButton("\u8FD4\u56DE");// ����������
		btn_back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					HomePage_1 homePage_1 = new HomePage_1();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btn_back.setBounds(10, 10, 93, 23);
		contentPane.add(btn_back);

		JButton btn_settleAccounts = new JButton("\u7ACB\u5373\u7ED3\u7B97");// ��������
		btn_settleAccounts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					ShoppingCart shoppingCart=new ShoppingCart();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btn_settleAccounts.setBounds(353, 283, 107, 23);
		contentPane.add(btn_settleAccounts);
		
		numField = new JTextField();
		numField.setEditable(false);
		numField.setText("1");
		numField.setBounds(118, 252, 13, 21);
		contentPane.add(numField);
		numField.setColumns(10);
		
	
		num=1;//��ʼ����������
		
		JButton btn_Minus = new JButton("-");
		btn_Minus.setEnabled(false);
		btn_Minus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=Integer.parseInt(numField.getText());
				num--;
				numField.setText(Integer.toString(num));
				if(num<2)
				{
					btn_Minus.setEnabled(false);
				}
			}
		});
		btn_Minus.setBounds(58, 251, 45, 23);
		contentPane.add(btn_Minus);
		
		JButton btn_Add = new JButton("+");
		btn_Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=Integer.parseInt(numField.getText());
				num++;
				numField.setText(Integer.toString(num));
				
				if(num>1)
				{
					btn_Minus.setEnabled(true);
				}
				
			}
		});
		btn_Add.setBounds(147, 251, 45, 23);
		contentPane.add(btn_Add);

		Connection connection = null;
		PreparedStatement pstmt = null;
		String searchSql = "SELECT * FROM 2014302580103_pet WHERE id = ? ";
		Class.forName(DBDRIVER);
		connection = DriverManager.getConnection(DBURL, "root", "123456");// �������ݿ�
		// System.out.println("���ݿ����ӳɹ���");
		pstmt = connection.prepareStatement(searchSql);
		pstmt.setString(1, Integer.toString(6));
		ResultSet rs = pstmt.executeQuery();
		if (rs.next()) {
			nameField.setText(rs.getString(2));
			eatFiled.setText(rs.getString(3));
			drinkField.setText(rs.getString(4));
			liveField.setText(rs.getString(5));
			hobbyField.setText(rs.getString(6));
			priceField.setText(Double.toString(rs.getDouble(7)));
			stockField.setText(Integer.toString(rs.getInt(8)));
		}
	}
}
