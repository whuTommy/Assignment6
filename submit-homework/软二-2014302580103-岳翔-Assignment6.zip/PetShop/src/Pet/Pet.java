package Pet;

import java.util.ArrayList;

public class Pet {
	private static ArrayList<Integer> id=new ArrayList<Integer>();
	private static ArrayList<Integer> num=new ArrayList<Integer>();
	private static ArrayList<Integer> stockNum=new ArrayList<Integer>();

	public static int getId(int index) {
		return id.get(index);
		
	}

	public static void setId(int id) {
		//System.out.println(Pet.id.size());
		Pet.id.add(id);
		//System.out.println(Pet.id.size());
	}

	public static int getNum(int index) {
		return num.get(index);
		
	}
	
	public static int getLength()
	{
		return id.size();
	}

	public static void setNum(int num) {
		Pet.num.add(num);
	}

	public static int getStockNum(int index) {
		return stockNum.get(index);
		
	}

	public static void setStockNum(int stockNum) {
		//System.out.println(Pet.id.size());
		Pet.stockNum.add(stockNum);
		//System.out.println(Pet.id.size());
	}
}
