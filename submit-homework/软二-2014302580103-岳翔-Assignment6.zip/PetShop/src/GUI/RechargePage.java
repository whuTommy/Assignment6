package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.JButton;

import User.User;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RechargePage extends JFrame {

	private JPanel contentPane;
	private JTextField curBanlanceField;
	private JTextField rechargeBanlanceField;
	private double balance;// �˻����
	private double rechargeMoney;// ��ֵ���

	private final String DBDRIVER = "com.mysql.jdbc.Driver";
	private final String DBURL = "jdbc:mysql://127.0.0.1:3306/my_schema";// ��ַ

	public RechargePage() throws Exception {
		
		int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((curWidth - 250) / 2, (curHeight - 300) / 2, 250, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);

		JLabel label = new JLabel("\u8D26\u6237\u4F59\u989D\uFF1A");
		label.setFont(new Font("����", Font.PLAIN, 14));
		label.setBounds(33, 60, 75, 28);
		contentPane.add(label);

		curBanlanceField = new JTextField();
		curBanlanceField.setEditable(false);
		curBanlanceField.setBounds(101, 64, 98, 21);
		contentPane.add(curBanlanceField);
		curBanlanceField.setColumns(10);

		balance = User.getBalance();

		curBanlanceField.setText(Double.toString(balance));

		JLabel label_1 = new JLabel("\u5145\u503C\u91D1\u989D\uFF1A");
		label_1.setFont(new Font("����", Font.PLAIN, 14));
		label_1.setBounds(32, 126, 75, 28);
		contentPane.add(label_1);

		rechargeBanlanceField = new JTextField();
		rechargeBanlanceField.setColumns(10);
		rechargeBanlanceField.setBounds(100, 130, 98, 21);
		contentPane.add(rechargeBanlanceField);

		JLabel label_2 = new JLabel("\uFF08\u4E0A\u9650500\u5143\uFF09");
		label_2.setFont(new Font("����", Font.PLAIN, 14));
		label_2.setBounds(101, 159, 98, 28);
		contentPane.add(label_2);

		JButton button = new JButton("\u5145   \u503C");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				rechargeMoney = Double.parseDouble(rechargeBanlanceField
						.getText());
				if (rechargeMoney <= 500) {
					balance += rechargeMoney;
					
					String balanceString=String.format("%.2f",balance);//����С�������λ
					balance=Double.parseDouble(balanceString);
					
					User.setBalance(balance);// �����˻����

				//	System.out.println(balance);

					Connection connection = null;
					PreparedStatement pstmt = null;
					// String searchSql =
					// "SELECT * FROM 2014302580103_pet WHERE id = ? ";

					//System.out.println(User.getUsername());
					String updateSql = " UPDATE 2014302580103_user SET balane="
							+ balance + "WHERE username= '"+User.getUsername()+"'";
					try {
						Class.forName(DBDRIVER);
						connection = DriverManager.getConnection(DBURL, "root",
								"123456");
						pstmt = connection.prepareStatement(updateSql);
						pstmt.executeUpdate();

						JOptionPane.showMessageDialog(null, "��ϲ������ֵ�ɹ�", "�ɹ�",
								JOptionPane.PLAIN_MESSAGE);

						dispose();
						HomePage_1 homePage = new HomePage_1();

					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} else {
					JOptionPane.showMessageDialog(null, "�Բ��𣬳�����ֵ����޶�",
							"ʧ��", JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		button.setBounds(61, 209, 107, 28);
		contentPane.add(button);

		JButton button_1 = new JButton("\u8FD4\u56DE");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();

				try {
					HomePage_1 homePage_1 = new HomePage_1();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		button_1.setBounds(10, 10, 67, 23);
		contentPane.add(button_1);
		this.setVisible(true);
	}

}
