package GUI;

import iss.java.mail.HomeworkLoader;

import javax.mail.MessagingException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Toolkit;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RegisterPage extends JFrame {

	private JPanel contentPane;
	private JTextField usernameField;
	private JTextField emailField;
	private JTextField truenameField;
	private JPasswordField passwordField;
	private final String DBDRIVER = "com.mysql.jdbc.Driver";
	private final String DBURL = "jdbc:mysql://127.0.0.1:3306/my_schema";// ��ַ

	private String identifyingCode;// ��֤��

	private boolean flag = true;// ���
	private JTextField identifyingCodeField;

	public RegisterPage() {

		int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((curWidth - 350) / 2, (curHeight - 400) / 2, 440, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);

		JLabel label = new JLabel("\u6CE8    \u518C");
		label.setFont(new Font("����", Font.PLAIN, 17));
		label.setBounds(120, 21, 84, 36);
		contentPane.add(label);

		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Consolas", Font.PLAIN, 15));
		lblUsername.setBounds(41, 77, 75, 22);
		contentPane.add(lblUsername);

		usernameField = new JTextField();
		usernameField.setBounds(126, 78, 159, 21);
		contentPane.add(usernameField);
		usernameField.setColumns(10);

		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Consolas", Font.PLAIN, 15));
		lblPassword.setBounds(41, 125, 75, 22);
		contentPane.add(lblPassword);

		JLabel lblEmail = new JLabel("  E-mail:");
		lblEmail.setFont(new Font("Consolas", Font.PLAIN, 15));
		lblEmail.setBounds(41, 225, 75, 22);
		contentPane.add(lblEmail);

		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBounds(126, 226, 159, 21);
		contentPane.add(emailField);

		JLabel lblTruename = new JLabel("Truename:");
		lblTruename.setFont(new Font("Consolas", Font.PLAIN, 15));
		lblTruename.setBounds(41, 175, 75, 22);
		contentPane.add(lblTruename);

		truenameField = new JTextField();
		truenameField.setColumns(10);
		truenameField.setBounds(126, 176, 159, 21);
		contentPane.add(truenameField);

		JButton bt_register = new JButton("ע         ��");
		bt_register.addActionListener(new ActionListener() {

			@SuppressWarnings({ "deprecation", "null" })
			public void actionPerformed(ActionEvent e) {

				/*
				 * Connection connection=null; PreparedStatement pstmt=null;
				 * String sql=
				 * "INSERT INTO teacherInfomation(name,tel,email,text)VALUES(?,?,?,?)"
				 * ; Class.forName(DBDRIVER);//������������
				 * connection=DriverManager.getConnection
				 * (DBURL,"root","123456");//�������ݿ�
				 * pstmt=connection.prepareStatement(sql);
				 */

				Connection connection = null;
				PreparedStatement pstmt = null;
				String insertSql = "INSERT INTO 2014302580103_user(username,password,email,truename,balane)VALUES(?,?,?,?,?)";
				String searchSql = "SELECT * FROM 2014302580103_user WHERE username = ? ";

				try {
					Class.forName(DBDRIVER);
					connection = DriverManager.getConnection(DBURL, "root",
							"123456");// �������ݿ�
					pstmt = connection.prepareStatement(searchSql);
					pstmt.setString(1, usernameField.getText());
					ResultSet rs = pstmt.executeQuery();
					flag = rs.next();
					if (flag) {
						JOptionPane.showMessageDialog(null, "�Բ����û����ѱ�ע��",
								"����", JOptionPane.ERROR_MESSAGE);
					} else {
						if (identifyingCode.equals(identifyingCodeField
								.getText())) {
							pstmt = connection.prepareStatement(insertSql);
							pstmt.setString(1, usernameField.getText());
							pstmt.setString(2, passwordField.getText());
							pstmt.setString(3, emailField.getText());
							pstmt.setString(4, truenameField.getText());
							pstmt.setDouble(5, 1000);
							pstmt.executeUpdate();
							JOptionPane.showMessageDialog(null, "��ϲ����ע��ɹ�",
									"�ɹ�", JOptionPane.PLAIN_MESSAGE);
							dispose();
							LoginPage loginPage = new LoginPage();
						} else {
							JOptionPane.showMessageDialog(null,
									"�Բ������������֤�벻��ȷ", "����",
									JOptionPane.ERROR_MESSAGE);
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}// ������������

			}
		});
		bt_register.setBounds(152, 315, 186, 23);
		contentPane.add(bt_register);

		passwordField = new JPasswordField();
		passwordField.setBounds(126, 126, 159, 22);
		contentPane.add(passwordField);

		JButton button = new JButton("����");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				LoginPage loginPage = new LoginPage();
			}
		});
		button.setBounds(10, 10, 64, 23);
		contentPane.add(button);

		JButton button_1 = new JButton("����û���");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Connection connection = null;
				PreparedStatement pstmt = null;
				String searchSql = "SELECT * FROM 2014302580103_user WHERE username = ? ";
				try {
					Class.forName(DBDRIVER);

					connection = DriverManager.getConnection(DBURL, "root",
							"123456");// �������ݿ�
					pstmt = connection.prepareStatement(searchSql);
					pstmt.setString(1, usernameField.getText());
					ResultSet rs = pstmt.executeQuery();
					flag = rs.next();
					if (flag) {
						JOptionPane.showMessageDialog(null, "�Բ����û����ѱ�ע�ᣡ",
								"����", JOptionPane.ERROR_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null,
								"��ϲ��������ʹ�ô��û�������ע�ᣡ", "�ɹ�",
								JOptionPane.PLAIN_MESSAGE);
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		});
		button_1.setBounds(310, 76, 104, 23);
		contentPane.add(button_1);

		JButton button_2 = new JButton("������֤��");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String text = emailField.getText();
				String regex2 = "[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+";
				Pattern p2 = Pattern.compile(regex2);
				Matcher m2 = p2.matcher(text);
				if (m2.find()) {

					try {
						HomeworkLoader homeworkLoader = new HomeworkLoader(
								emailField.getText(), truenameField.getText());
						identifyingCode = homeworkLoader.getIdentifyingCode();

						JOptionPane.showMessageDialog(null, "�ѳɹ������ʼ�������գ�",
								"�ɹ�", JOptionPane.PLAIN_MESSAGE);

					} catch (IllegalAccessException | InstantiationException
							| MessagingException | IOException
							| InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} else {
					JOptionPane.showMessageDialog(null, "��������ȷ�������ַ��",
							"ʧ��", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_2.setBounds(310, 224, 104, 23);
		contentPane.add(button_2);

		identifyingCodeField = new JTextField();
		identifyingCodeField.setColumns(10);
		identifyingCodeField.setBounds(126, 269, 159, 21);
		contentPane.add(identifyingCodeField);

		JLabel label_1 = new JLabel("\u9A8C\u8BC1\u7801\uFF1A");
		label_1.setFont(new Font("����", Font.PLAIN, 13));
		label_1.setBounds(66, 271, 54, 15);
		contentPane.add(label_1);
		this.setVisible(true);
	}
}
