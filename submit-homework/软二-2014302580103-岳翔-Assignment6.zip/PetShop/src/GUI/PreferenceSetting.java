package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import User.User;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PreferenceSetting extends JFrame {

	private JPanel contentPane;
	private JTextField usernameField;
	private JTextField balanceField;
	private JTextField emailField;
	private JTextField truenameField;

	
	public PreferenceSetting() {
		
		int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((curWidth - 278) / 2, (curHeight - 354) / 2, 278, 354);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel label = new JLabel("\u4E2A \u4EBA \u4FE1 \u606F");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(73, 36, 131, 24);
		contentPane.add(label);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("����", Font.PLAIN, 14));
		lblUsername.setBounds(10, 88, 71, 24);
		contentPane.add(lblUsername);
		
		usernameField = new JTextField();
		usernameField.setEditable(false);
		usernameField.setBounds(77, 90, 171, 21);
		contentPane.add(usernameField);
		usernameField.setColumns(10);
		usernameField.setText(User.getUsername());
		
		JLabel lblBalance = new JLabel("Balance:");
		lblBalance.setFont(new Font("����", Font.PLAIN, 14));
		lblBalance.setBounds(10, 139, 71, 24);
		contentPane.add(lblBalance);
		
		balanceField = new JTextField();
		balanceField.setEditable(false);
		balanceField.setColumns(10);
		balanceField.setBounds(77, 141, 171, 21);
		contentPane.add(balanceField);
		balanceField.setText(Double.toString(User.getBalance()));
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("����", Font.PLAIN, 14));
		lblEmail.setBounds(10, 193, 71, 24);
		contentPane.add(lblEmail);
		
		emailField = new JTextField();
		emailField.setEditable(false);
		emailField.setColumns(10);
		emailField.setBounds(77, 195, 171, 21);
		contentPane.add(emailField);
		emailField.setText(User.getEmailAddress());
		
		JLabel lblTruename = new JLabel("Truename:");
		lblTruename.setFont(new Font("����", Font.PLAIN, 14));
		lblTruename.setBounds(10, 249, 71, 24);
		contentPane.add(lblTruename);
		
		truenameField = new JTextField();
		truenameField.setEditable(false);
		truenameField.setColumns(10);
		truenameField.setBounds(77, 251, 171, 21);
		contentPane.add(truenameField);
		truenameField.setText(User.getTruename());
		
		JButton button = new JButton("\u8FD4\u56DE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					HomePage_1 homePage_1=new HomePage_1();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button.setBounds(10, 10, 63, 23);
		contentPane.add(button);
		this.setVisible(true);
	}
}
