package GUI;

import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.CardLayout;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.IntToDoubleFunction;

import javax.swing.Icon;

import PetDetailGUI.CatDetail;
import PetDetailGUI.DogDetail;
import PetDetailGUI.HamsterDetail;
import PetDetailGUI.ParrotDetail;
import PetDetailGUI.RabbitDetail;
import PetDetailGUI.SnakeDetail;
import PetDetailGUI.SquirrelDetail;
import PetDetailGUI.TurtleDetail;
import User.User;

public class HomePage_1 extends JFrame {

	private JPanel contentPane;
	private JTextField nameField_1;
	private JTextField IDField_1;
	private JTextField IDField_2;
	private JTextField nameField_2;
	private JTextField IDField_3;
	private JTextField nameField_3;
	private JTextField IDField_4;
	private JTextField nameField_4;
	private JTextField IDField_5;
	private JTextField nameField_5;
	private JTextField IDField_6;
	private JTextField nameField_6;
	private JTextField IDField_7;
	private JTextField nameField_7;
	private JTextField IDField_8;
	private JTextField nameField_8;

	private final String DBDRIVER = "com.mysql.jdbc.Driver";
	private final String DBURL = "jdbc:mysql://127.0.0.1:3306/my_schema";// ��ַ

	public HomePage_1() throws Exception {

		int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((curWidth - 800) / 2, (curHeight - 600) / 2, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("����", Font.PLAIN, 13));
		lblName.setBounds(100, 235, 54, 15);
		contentPane.add(lblName);

		nameField_1 = new JTextField();
		nameField_1.setEditable(false);
		nameField_1.setBounds(134, 232, 90, 21);
		contentPane.add(nameField_1);
		nameField_1.setColumns(10);

		IDField_1 = new JTextField();
		IDField_1.setText("1");
		IDField_1.setEditable(false);
		IDField_1.setColumns(10);
		IDField_1.setBounds(134, 196, 90, 21);
		contentPane.add(IDField_1);

		JLabel lblId = new JLabel("ID:");
		lblId.setFont(new Font("����", Font.PLAIN, 13));
		lblId.setBounds(100, 199, 54, 15);
		contentPane.add(lblId);

		JLabel label_2 = new JLabel("ID:");
		label_2.setFont(new Font("����", Font.PLAIN, 13));
		label_2.setBounds(252, 196, 54, 15);
		contentPane.add(label_2);

		IDField_2 = new JTextField();
		IDField_2.setText("2");
		IDField_2.setEditable(false);
		IDField_2.setColumns(10);
		IDField_2.setBounds(286, 193, 90, 21);
		contentPane.add(IDField_2);

		nameField_2 = new JTextField();
		nameField_2.setEditable(false);
		nameField_2.setColumns(10);
		nameField_2.setBounds(286, 229, 90, 21);
		contentPane.add(nameField_2);

		JLabel label_3 = new JLabel("Name:");
		label_3.setFont(new Font("����", Font.PLAIN, 13));
		label_3.setBounds(252, 232, 54, 15);
		contentPane.add(label_3);

		JLabel label_5 = new JLabel("ID:");
		label_5.setFont(new Font("����", Font.PLAIN, 13));
		label_5.setBounds(405, 196, 54, 15);
		contentPane.add(label_5);

		IDField_3 = new JTextField();
		IDField_3.setText("3");
		IDField_3.setEditable(false);
		IDField_3.setColumns(10);
		IDField_3.setBounds(439, 193, 90, 21);
		contentPane.add(IDField_3);

		nameField_3 = new JTextField();
		nameField_3.setEditable(false);
		nameField_3.setColumns(10);
		nameField_3.setBounds(439, 229, 90, 21);
		contentPane.add(nameField_3);

		JLabel label_6 = new JLabel("Name:");
		label_6.setFont(new Font("����", Font.PLAIN, 13));
		label_6.setBounds(405, 232, 54, 15);
		contentPane.add(label_6);

		JLabel label_8 = new JLabel("ID:");
		label_8.setFont(new Font("����", Font.PLAIN, 13));
		label_8.setBounds(567, 196, 54, 15);
		contentPane.add(label_8);

		IDField_4 = new JTextField();
		IDField_4.setText("4");
		IDField_4.setEditable(false);
		IDField_4.setColumns(10);
		IDField_4.setBounds(601, 193, 90, 21);
		contentPane.add(IDField_4);

		nameField_4 = new JTextField();
		nameField_4.setEditable(false);
		nameField_4.setColumns(10);
		nameField_4.setBounds(601, 229, 90, 21);
		contentPane.add(nameField_4);

		JLabel label_9 = new JLabel("Name:");
		label_9.setFont(new Font("����", Font.PLAIN, 13));
		label_9.setBounds(567, 232, 54, 15);
		contentPane.add(label_9);

		JLabel label_11 = new JLabel("ID:");
		label_11.setFont(new Font("����", Font.PLAIN, 13));
		label_11.setBounds(100, 405, 54, 15);
		contentPane.add(label_11);

		IDField_5 = new JTextField();
		IDField_5.setText("5");
		IDField_5.setEditable(false);
		IDField_5.setColumns(10);
		IDField_5.setBounds(134, 402, 90, 21);
		contentPane.add(IDField_5);

		nameField_5 = new JTextField();
		nameField_5.setEditable(false);
		nameField_5.setColumns(10);
		nameField_5.setBounds(134, 438, 90, 21);
		contentPane.add(nameField_5);

		JLabel label_12 = new JLabel("Name:");
		label_12.setFont(new Font("����", Font.PLAIN, 13));
		label_12.setBounds(100, 441, 54, 15);
		contentPane.add(label_12);

		JLabel label_14 = new JLabel("ID:");
		label_14.setFont(new Font("����", Font.PLAIN, 13));
		label_14.setBounds(252, 405, 54, 15);
		contentPane.add(label_14);

		IDField_6 = new JTextField();
		IDField_6.setText("6");
		IDField_6.setEditable(false);
		IDField_6.setColumns(10);
		IDField_6.setBounds(286, 402, 90, 21);
		contentPane.add(IDField_6);

		nameField_6 = new JTextField();
		nameField_6.setEditable(false);
		nameField_6.setColumns(10);
		nameField_6.setBounds(286, 438, 90, 21);
		contentPane.add(nameField_6);

		JLabel label_15 = new JLabel("Name:");
		label_15.setFont(new Font("����", Font.PLAIN, 13));
		label_15.setBounds(252, 441, 54, 15);
		contentPane.add(label_15);

		JLabel label_17 = new JLabel("ID:");
		label_17.setFont(new Font("����", Font.PLAIN, 13));
		label_17.setBounds(405, 405, 54, 15);
		contentPane.add(label_17);

		IDField_7 = new JTextField();
		IDField_7.setText("7");
		IDField_7.setEditable(false);
		IDField_7.setColumns(10);
		IDField_7.setBounds(439, 402, 90, 21);
		contentPane.add(IDField_7);

		nameField_7 = new JTextField();
		nameField_7.setEditable(false);
		nameField_7.setColumns(10);
		nameField_7.setBounds(439, 438, 90, 21);
		contentPane.add(nameField_7);

		JLabel label_18 = new JLabel("Name:");
		label_18.setFont(new Font("����", Font.PLAIN, 13));
		label_18.setBounds(405, 441, 54, 15);
		contentPane.add(label_18);

		JLabel label_20 = new JLabel("ID:");
		label_20.setFont(new Font("����", Font.PLAIN, 13));
		label_20.setBounds(567, 405, 54, 15);
		contentPane.add(label_20);

		IDField_8 = new JTextField();
		IDField_8.setText("8");
		IDField_8.setEditable(false);
		IDField_8.setColumns(10);
		IDField_8.setBounds(601, 402, 90, 21);
		contentPane.add(IDField_8);

		nameField_8 = new JTextField();
		nameField_8.setEditable(false);
		nameField_8.setColumns(10);
		nameField_8.setBounds(601, 438, 90, 21);
		contentPane.add(nameField_8);

		JLabel label_21 = new JLabel("Name:");
		label_21.setFont(new Font("����", Font.PLAIN, 13));
		label_21.setBounds(567, 441, 54, 15);
		contentPane.add(label_21);

		JButton button = new JButton("��һҳ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					HomePage_2 homePage_2 = new HomePage_2();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button.setBounds(637, 496, 93, 23);
		contentPane.add(button);
		
		Connection connection = null;
		PreparedStatement pstmt = null;
		String searchSql = "SELECT * FROM 2014302580103_pet WHERE id = ? ";
		Class.forName(DBDRIVER);
		connection = DriverManager.getConnection(DBURL, "root", "123456");// �������ݿ�
		//System.out.println("���ݿ����ӳɹ���");
		for (int i = 1; i <= 8; i++) {
			pstmt = connection.prepareStatement(searchSql);
			pstmt.setString(1,Integer.toString(i));
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				switch(i)
				{
				case 1:
					nameField_1.setText(rs.getString(2));
					break;
				case 2:
					nameField_2.setText(rs.getString(2));
					break;
				case 3:
					nameField_3.setText(rs.getString(2));
					break;
				case 4:
					nameField_4.setText(rs.getString(2));
					break;
				case 5:
					nameField_5.setText(rs.getString(2));
					break;
				case 6:
					nameField_6.setText(rs.getString(2));
					break;
				case 7:
					nameField_7.setText(rs.getString(2));
					break;
				case 8:
					nameField_8.setText(rs.getString(2));
					break;
				}
			}
		}

		String imagePath;//ͼƬ·��
		
		imagePath="image/"+nameField_1.getText()+".png";
		JButton btnNewButton = new JButton(new ImageIcon(imagePath));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					DogDetail dogDetail=new DogDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(94, 83, 130, 100);
		contentPane.add(btnNewButton);

		imagePath="image/"+nameField_2.getText()+".png";
		JButton button_1 =new JButton(new ImageIcon(imagePath));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dispose();
					CatDetail catDetail=new CatDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_1.setBounds(252, 83, 130, 100);
		contentPane.add(button_1);

		imagePath="image/"+nameField_3.getText()+".png";
		JButton button_2 = new JButton(new ImageIcon(imagePath));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					TurtleDetail turtleDetail=new TurtleDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_2.setBounds(405, 83, 130, 100);
		contentPane.add(button_2);

		imagePath="image/"+nameField_4.getText()+".png";
		JButton button_3 = new JButton(new ImageIcon(imagePath));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					ParrotDetail parrotDetail=new ParrotDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_3.setBounds(567, 83, 130, 100);
		contentPane.add(button_3);

		imagePath="image/"+nameField_5.getText()+".png";
		JButton button_4 = new JButton(new ImageIcon(imagePath));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					HamsterDetail hamsterDetail=new HamsterDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_4.setBounds(94, 292, 130, 100);
		contentPane.add(button_4);

		imagePath="image/"+nameField_6.getText()+".png";
		JButton button_5 = new JButton(new ImageIcon(imagePath));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					SquirrelDetail squirrelDetail=new SquirrelDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_5.setBounds(252, 292, 130, 100);
		contentPane.add(button_5);

		imagePath="image/"+nameField_7.getText()+".png";
		JButton button_6 = new JButton(new ImageIcon(imagePath));
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					RabbitDetail rabbitDetail=new RabbitDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_6.setBounds(405, 292, 130, 100);
		contentPane.add(button_6);

		imagePath="image/"+nameField_8.getText()+".png";
		JButton button_7 = new JButton(new ImageIcon(imagePath));
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					SnakeDetail snakeDetail=new SnakeDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_7.setBounds(567, 292, 130, 100);
		contentPane.add(button_7);
		
		String str=User.getTruename();
		JLabel lblHello = new JLabel("Hello !"+str+" ����/Ůʿ");
		lblHello.setFont(new Font("����", Font.PLAIN, 16));
		lblHello.setBounds(36, 15, 215, 15);
		contentPane.add(lblHello);
		
		JButton button_8 = new JButton("\u4FE1\u606F\u67E5\u8BE2");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				PreferenceSetting preferenceSetting=new PreferenceSetting();
			}
		});
		button_8.setBounds(681, 12, 93, 23);
		contentPane.add(button_8);
		
		JButton button_9 = new JButton("\u8D26\u6237\u5145\u503C");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					RechargePage recharge=new RechargePage();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_9.setBounds(681, 50, 93, 23);
		contentPane.add(button_9);
		this.setVisible(true);
	}
}
