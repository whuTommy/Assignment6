package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTree;
import javax.swing.JTextArea;
import javax.swing.JTable;

import Pet.Pet;
import User.User;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ScrollPaneConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ShoppingCart extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private int id[];// ����ID����
	private double sum = 0;// �ܼ�
	private double balance;
	private int num; 
	private int stockNum;
	private Connection connection = null;
	private PreparedStatement pstmt = null;

	private final String DBDRIVER = "com.mysql.jdbc.Driver";
	private final String DBURL = "jdbc:mysql://127.0.0.1:3306/my_schema";// ��ַ

	public ShoppingCart() throws Exception {

		int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((curWidth - 450) / 2, (curHeight - 300) / 2, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		this.setVisible(true);

		JLabel label = new JLabel("\u8D2D\u7269\u8F66");
		label.setFont(new Font("����", Font.PLAIN, 16));
		label.setBounds(184, 10, 64, 15);
		contentPane.add(label);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 41, 368, 152);

		contentPane.add(scrollPane);

		int animalNum = Pet.getLength();// ��ȡ��������
		
		// System.out.println(animalNum);

		id = new int[animalNum];// ��ʼ��ID����

		String[] columnNames = { "ID", "Name", "Price", "Num", "Money" };
		Object[][] cellData = new Object[animalNum + 1][5];//

		String searchSql = "SELECT * FROM 2014302580103_pet WHERE id = ? ";
		
		Class.forName(DBDRIVER);
		connection = DriverManager.getConnection(DBURL, "root", "123456");// �������ݿ�
		// System.out.println("���ݿ����ӳɹ���");
		pstmt = connection.prepareStatement(searchSql);

		for (int i = 0; i <= animalNum; i++) {
			if (i != animalNum) {
				id[i] = Pet.getId(i);
				cellData[i][0] = id[i];
				pstmt.setString(1, Integer.toString(id[i]));
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) {
					cellData[i][1] = rs.getString(2);
					cellData[i][2] = rs.getDouble(7);
					double price = rs.getDouble(7);// ����
					cellData[i][3] = Pet.getNum(i);
					num = Pet.getNum(i);// ���������
					
					cellData[i][4] = price * num;// С��
					sum += price * num;
				}
			} else {
				cellData[i][0] = "�ϼ�";
				cellData[i][4] = sum;
			}
		}
		
		
		
		
		
		table = new JTable(cellData, columnNames);
		scrollPane.setViewportView(table);

		JButton button = new JButton("����");

		// String updateSql = "SELECT * FROM 2014302580103_pet WHERE id = ? ";

		balance = User.getBalance() - sum;

		String balanceString=String.format("%.2f",balance);
		
		String updateSql = " UPDATE 2014302580103_user SET balane=" + balanceString
				+ "WHERE username= '"+User.getUsername()+"'";

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (balance >= 0) {
					
					for(int i=0;i<id.length;i++)
					{
						stockNum=Pet.getStockNum(i);
						num=Pet.getNum(i);
						stockNum-=num;
						String updateSqlStr="update 2014302580103_pet SET stock="+stockNum+" WHERE id="+id[i];
						//System.out.println(updateSqlStr);
						try {
							pstmt = connection.prepareStatement(updateSqlStr);
							pstmt.executeUpdate();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
					try {
						pstmt = connection.prepareStatement(updateSql);
						pstmt.executeUpdate();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					JOptionPane.showMessageDialog(null, "��ϲ��������ɹ���", "�ɹ�",
							JOptionPane.PLAIN_MESSAGE);
					JOptionPane.showMessageDialog(null, "��ӭ�´ι���С�꣡", "�ɹ�",
							JOptionPane.PLAIN_MESSAGE);
					dispose();
				}

				else {
					JOptionPane.showMessageDialog(null, "�Բ��������˻����㣡", "ʧ��",
							JOptionPane.ERROR_MESSAGE);
					JOptionPane.showMessageDialog(null, "�뷵�س�ֵ������г�ֵ��", "ʧ��",
							JOptionPane.ERROR_MESSAGE);
					dispose();
					try {
						RechargePage rechargePage=new RechargePage();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		button.setBounds(301, 215, 93, 23);
		contentPane.add(button);
	}
}
