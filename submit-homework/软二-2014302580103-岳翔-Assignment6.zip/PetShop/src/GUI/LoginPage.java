package GUI;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;

import Main.Main2014302580103;
import User.User;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginPage extends JFrame {

	private JPanel contentPane;
	private JPasswordField passwordField;
	private JTextField usernameField;
	private final String DBDRIVER = "com.mysql.jdbc.Driver";
	private final String DBURL = "jdbc:mysql://127.0.0.1:3306/my_schema";// ��ַ
	private boolean flag = true;// ���

	public LoginPage() {
		
		int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((curWidth - 450) / 2, (curHeight-300)/2, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);

		JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
		label.setFont(new Font("����", Font.PLAIN, 15));
		label.setBounds(82, 82, 63, 23);
		contentPane.add(label);

		JLabel label_1 = new JLabel("\u5BC6  \u7801\uFF1A");
		label_1.setFont(new Font("����", Font.PLAIN, 15));
		label_1.setBounds(82, 134, 63, 23);
		contentPane.add(label_1);

		passwordField = new JPasswordField();
		passwordField.setBounds(160, 135, 170, 22);
		contentPane.add(passwordField);

		usernameField = new JTextField();
		usernameField.setBounds(160, 80, 170, 22);
		contentPane.add(usernameField);
		usernameField.setColumns(10);

		JButton button = new JButton("\u6CE8\u518C");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				RegisterPage registerPage = new RegisterPage();
			}
		});
		button.setBounds(96, 184, 93, 23);
		contentPane.add(button);

		JButton button_1 = new JButton("��½");
		button_1.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				String username;
				String password;

				Connection connection = null;
				PreparedStatement pstmt = null;
				String searchSql = "SELECT * FROM 2014302580103_user WHERE username = ? ";

				try {
					Class.forName(DBDRIVER);
					connection = DriverManager.getConnection(DBURL, "root",
							"123456");// �������ݿ�
					pstmt = connection.prepareStatement(searchSql);
					pstmt.setString(1, usernameField.getText());// �����ݿ��в����Ƿ�������û���
					ResultSet rs = pstmt.executeQuery();
					flag = rs.next();
					
					if (flag)// ������û���
					{
						password = rs.getString(3);// ��ȡ������
						
						//System.out.println("��ȡ�����ݿ��е����룺" + password);
						//System.out.println("������е�����:" + passwordField.getText());

						if (password.equals(passwordField.getText()))// �������ƥ��
						{
							
							User.setUsername(usernameField.getText());//��¼�û���
							User.setEmailAddress(rs.getString(4));//��¼����
							User.setTruename(rs.getString(5));//��¼��ʵ
							User.setBalance(rs.getDouble(6));//��¼�˻����
							
							JOptionPane.showMessageDialog(null, "��ϲ������½�ɹ�",
									"�ɹ�", JOptionPane.PLAIN_MESSAGE);
						
							dispose();
							HomePage_1 homePage=new HomePage_1();
						} else {
							JOptionPane.showMessageDialog(null, "�Բ����û������������",
									"ʧ��", JOptionPane.PLAIN_MESSAGE);
						}
					}
					else{
						JOptionPane.showMessageDialog(null, "�Բ����û������������",
								"ʧ��", JOptionPane.PLAIN_MESSAGE);
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}// ������������

				

			}

		});
		button_1.setBounds(228, 184, 93, 23);
		contentPane.add(button_1);

		JLabel label_2 = new JLabel("\u5BA0  \u7269  \u5546  \u5E97");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(146, 26, 139, 23);
		contentPane.add(label_2);
		this.setVisible(true);
	}

}
