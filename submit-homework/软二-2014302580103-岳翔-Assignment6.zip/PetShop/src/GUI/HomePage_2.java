package GUI;

import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.CardLayout;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.Icon;

import PetDetailGUI.CanaryDetail;
import PetDetailGUI.FishDetail;
import PetDetailGUI.JumptigerDetail;
import PetDetailGUI.LizardDetail;
import PetDetailGUI.MynaDetail;

public class HomePage_2 extends JFrame {

	private JPanel contentPane;
	private JTextField nameField_9;
	private JTextField IDField_9;
	private JTextField IDField_10;
	private JTextField nameField_10;
	private JTextField IDField_11;
	private JTextField nameField_11;
	private JTextField IDField_12;
	private JTextField nameField_12;
	private JTextField IDField_13;
	private JTextField nameField_13;

	private final String DBDRIVER = "com.mysql.jdbc.Driver";
	private final String DBURL = "jdbc:mysql://127.0.0.1:3306/my_schema";// ���ݿ��ַ

	public HomePage_2() throws Exception {

		int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((curWidth - 800) / 2, (curHeight - 600) / 2, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("����", Font.PLAIN, 13));
		lblName.setBounds(94, 208, 54, 15);
		contentPane.add(lblName);

		nameField_9 = new JTextField();
		nameField_9.setEditable(false);
		nameField_9.setBounds(128, 205, 90, 21);
		contentPane.add(nameField_9);
		nameField_9.setColumns(10);

		IDField_9 = new JTextField();
		IDField_9.setText("9");
		IDField_9.setEditable(false);
		IDField_9.setColumns(10);
		IDField_9.setBounds(128, 169, 90, 21);
		contentPane.add(IDField_9);

		JLabel lblId = new JLabel("ID:");
		lblId.setFont(new Font("����", Font.PLAIN, 13));
		lblId.setBounds(94, 172, 54, 15);
		contentPane.add(lblId);

		JLabel label_2 = new JLabel("ID:");
		label_2.setFont(new Font("����", Font.PLAIN, 13));
		label_2.setBounds(246, 169, 54, 15);
		contentPane.add(label_2);

		IDField_10 = new JTextField();
		IDField_10.setText("10");
		IDField_10.setEditable(false);
		IDField_10.setColumns(10);
		IDField_10.setBounds(280, 166, 90, 21);
		contentPane.add(IDField_10);

		nameField_10 = new JTextField();
		nameField_10.setEditable(false);
		nameField_10.setColumns(10);
		nameField_10.setBounds(280, 202, 90, 21);
		contentPane.add(nameField_10);

		JLabel label_3 = new JLabel("Name:");
		label_3.setFont(new Font("����", Font.PLAIN, 13));
		label_3.setBounds(246, 205, 54, 15);
		contentPane.add(label_3);

		JLabel label_5 = new JLabel("ID:");
		label_5.setFont(new Font("����", Font.PLAIN, 13));
		label_5.setBounds(399, 169, 54, 15);
		contentPane.add(label_5);

		IDField_11 = new JTextField();
		IDField_11.setText("11");
		IDField_11.setEditable(false);
		IDField_11.setColumns(10);
		IDField_11.setBounds(433, 166, 90, 21);
		contentPane.add(IDField_11);

		nameField_11 = new JTextField();
		nameField_11.setEditable(false);
		nameField_11.setColumns(10);
		nameField_11.setBounds(433, 202, 90, 21);
		contentPane.add(nameField_11);

		JLabel label_6 = new JLabel("Name:");
		label_6.setFont(new Font("����", Font.PLAIN, 13));
		label_6.setBounds(399, 205, 54, 15);
		contentPane.add(label_6);

		JLabel label_8 = new JLabel("ID:");
		label_8.setFont(new Font("����", Font.PLAIN, 13));
		label_8.setBounds(561, 169, 54, 15);
		contentPane.add(label_8);

		IDField_12 = new JTextField();
		IDField_12.setText("12");
		IDField_12.setEditable(false);
		IDField_12.setColumns(10);
		IDField_12.setBounds(595, 166, 90, 21);
		contentPane.add(IDField_12);

		nameField_12 = new JTextField();
		nameField_12.setEditable(false);
		nameField_12.setColumns(10);
		nameField_12.setBounds(595, 202, 90, 21);
		contentPane.add(nameField_12);

		JLabel label_9 = new JLabel("Name:");
		label_9.setFont(new Font("����", Font.PLAIN, 13));
		label_9.setBounds(561, 205, 54, 15);
		contentPane.add(label_9);

		JLabel label_11 = new JLabel("ID:");
		label_11.setFont(new Font("����", Font.PLAIN, 13));
		label_11.setBounds(94, 378, 54, 15);
		contentPane.add(label_11);

		IDField_13 = new JTextField();
		IDField_13.setText("13");
		IDField_13.setEditable(false);
		IDField_13.setColumns(10);
		IDField_13.setBounds(128, 375, 90, 21);
		contentPane.add(IDField_13);

		nameField_13 = new JTextField();
		nameField_13.setEditable(false);
		nameField_13.setColumns(10);
		nameField_13.setBounds(128, 411, 90, 21);
		contentPane.add(nameField_13);

		JLabel label_12 = new JLabel("Name:");
		label_12.setFont(new Font("����", Font.PLAIN, 13));
		label_12.setBounds(94, 414, 54, 15);
		contentPane.add(label_12);

		JButton button = new JButton("��һҳ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					HomePage_1 homePage_1 = new HomePage_1();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button.setBounds(625, 479, 93, 23);
		contentPane.add(button);

		Connection connection = null;
		PreparedStatement pstmt = null;
		String searchSql = "SELECT * FROM 2014302580103_pet WHERE id = ? ";
		Class.forName(DBDRIVER);
		connection = DriverManager.getConnection(DBURL, "root", "123456");// �������ݿ�
		//System.out.println("���ݿ����ӳɹ���");
		for (int i = 9; i <= 13; i++) {
			pstmt = connection.prepareStatement(searchSql);
			pstmt.setString(1, Integer.toString(i));
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				switch (i) {
				case 9:
					nameField_9.setText(rs.getString(2));
					break;
				case 10:
					nameField_10.setText(rs.getString(2));
					break;
				case 11:
					nameField_11.setText(rs.getString(2));
					break;
				case 12:
					nameField_12.setText(rs.getString(2));
					break;
				case 13:
					nameField_13.setText(rs.getString(2));
					break;
				}
			}
		}

		String imagePath;// ͼƬ·��

		imagePath = "image/" + nameField_9.getText() + ".png";
		JButton button_1 = new JButton(new ImageIcon(imagePath));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					LizardDetail lizardDetail=new LizardDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_1.setBounds(94, 56, 130, 100);
		contentPane.add(button_1);

		imagePath = "image/" + nameField_10.getText() + ".png";
		JButton button_2 = new JButton(new ImageIcon(imagePath));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					FishDetail fishDetail=new FishDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_2.setBounds(246, 56, 130, 100);
		contentPane.add(button_2);

		imagePath = "image/" + nameField_11.getText() + ".png";
		JButton button_3 = new JButton(new ImageIcon(imagePath));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					MynaDetail mynaDetail=new MynaDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_3.setBounds(399, 56, 130, 100);
		contentPane.add(button_3);

		imagePath = "image/" + nameField_12.getText() + ".png";
		JButton button_4 = new JButton(new ImageIcon(imagePath));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					CanaryDetail canaryDetail =new CanaryDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_4.setBounds(561, 56, 130, 100);
		contentPane.add(button_4);

		imagePath = "image/" + nameField_13.getText() + ".png";
		JButton button_6 = new JButton(new ImageIcon(imagePath));
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				try {
					JumptigerDetail jumptigerDetail=new JumptigerDetail();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_6.setBounds(94, 265, 130, 100);
		contentPane.add(button_6);
		this.setVisible(true);
	}
}
